
import subprocess
import sys

if __name__ == "__main__":
    result = subprocess.run([
        sys.executable,
        "/content/debugging_agent.py",
        *sys.argv[1:]
    ])
    raise SystemExit(result.returncode)
