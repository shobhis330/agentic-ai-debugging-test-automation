
import ast
import json
import os
import subprocess
import sys
from pathlib import Path
from google import genai

BASE_DIR = Path("/content")
CASES_DIR = BASE_DIR / "evaluation_cases"
MODEL = "gemini-3.5-flash-lite"
MAX_RETRIES = 3


def get_client():
    key = os.environ.get("GEMINI_API_KEY")

    if not key:
        from google.colab import userdata
        key = userdata.get("GEMINI_API_KEY")

    if not key:
        raise RuntimeError("GEMINI_API_KEY is missing.")

    return genai.Client(api_key=key)


def run_tests(case_dir):
    result = subprocess.run(
        [sys.executable, "-m", "pytest", "-q", "--tb=short"],
        cwd=str(case_dir),
        capture_output=True,
        text=True,
        timeout=30
    )
    return result.returncode, result.stdout + result.stderr


def request_repair(client, code, feedback, function_name):
    prompt = f"""
You are a Python debugging agent.

Function name: {function_name}

Current code:
{code}

Pytest errors:
{feedback}

Return JSON with:
bug_type, explanation, fixed_code, confidence.

Preserve the function name.
Do not modify the tests.
Return only valid JSON.
"""

    response = client.models.generate_content(
        model=MODEL,
        contents=prompt,
        config={"response_mime_type": "application/json"}
    )

    data = json.loads(response.text)
    required = {"bug_type", "explanation", "fixed_code", "confidence"}

    if not required.issubset(data):
        raise ValueError("Invalid Gemini response.")

    fixed_code = data["fixed_code"]
    tree = ast.parse(fixed_code)

    functions = {
        node.name for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }

    if function_name not in functions:
        raise ValueError("Required function missing from repair.")

    compile(fixed_code, "candidate.py", "exec")
    return data


def repair_case(case_id):
    case_dir = CASES_DIR / case_id
    solution = case_dir / "solution.py"

    if not solution.exists():
        raise FileNotFoundError(f"Missing solution: {solution}")

    client = get_client()

    for attempt in range(MAX_RETRIES + 1):
        code = solution.read_text(encoding="utf-8")
        exit_code, feedback = run_tests(case_dir)

        print(f"\nTest run {attempt + 1}")
        print(feedback)

        if exit_code == 0:
            print("SUCCESS: All tests passed.")
            return True

        if attempt == MAX_RETRIES:
            break

        tree = ast.parse(code)
        functions = [
            node.name for node in tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        ]

        if not functions:
            raise ValueError("No function found in solution.")

        repair = request_repair(
            client, code, feedback, functions[0]
        )

        print("Bug:", repair["bug_type"])
        print("Explanation:", repair["explanation"])
        print("Confidence:", repair["confidence"])

        solution.write_text(
            repair["fixed_code"], encoding="utf-8"
        )

    print("Repair limit reached.")
    return False


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--case", required=True)
    args = parser.parse_args()

    success = repair_case(args.case.upper())
    sys.exit(0 if success else 1)
